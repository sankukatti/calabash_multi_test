require 'calabash-android/calabash_steps'

Then /^I enter "([^\"]*)" into webview input field clas "([^\"]*)"$/ do |text, clas|
  enter_text("android.webkit.WebView css:'input.#{clas}'",text);                
end

Then /^I enter "([^\"]*)" into webview textarea field clas "([^\"]*)"$/ do |text, clas|
  enter_text("android.webkit.WebView css:'textarea.#{clas}'",text);                
end

Then /^I enter "([^\"]*)" into webview input field number (\d+)$/ do |text, index|
  enter_text("android.webkit.WebView index:#{index.to_i-1}",text);                
end

Then /^I enter "([^\"]*)" into webview li field clas "([^\"]*)"$/ do |text, clas|
  enter_text("android.webkit.WebView css:'li.#{clas}'",text);                
end

Then /^I enter "([^\"]*)" into webview field with id "([^\"]*)"$/ do |text, id|
  enter_text("android.webkit.webView css:'#{id}'",text);                
end

Then /^I enter "([^\"]*)" into webview field with name "([^\"]*)"$/ do |text, id|
  enter_text("android.webkit.WebView css:'input[name=\"{id}\"]'",text);                
end

